/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_219(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_162(unsigned x)
{
    return x + 3284633920U;
}

unsigned getval_145()
{
    return 3277333653U;
}

void setval_159(unsigned *p)
{
    *p = 3267856712U;
}

unsigned addval_349(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_499()
{
    return 2421742168U;
}

void setval_128(unsigned *p)
{
    *p = 3281031240U;
}

void setval_324(unsigned *p)
{
    *p = 3281031768U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_469(unsigned x)
{
    return x + 3676886665U;
}

unsigned addval_112(unsigned x)
{
    return x + 3281046145U;
}

unsigned getval_107()
{
    return 3529556361U;
}

void setval_271(unsigned *p)
{
    *p = 3767097540U;
}

unsigned addval_104(unsigned x)
{
    return x + 3683961481U;
}

void setval_321(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_211()
{
    return 2429946208U;
}

unsigned addval_449(unsigned x)
{
    return x + 3286272328U;
}

void setval_118(unsigned *p)
{
    *p = 3682124169U;
}

unsigned getval_109()
{
    return 2429978904U;
}

unsigned addval_377(unsigned x)
{
    return x + 3381974665U;
}

unsigned getval_400()
{
    return 3246988088U;
}

unsigned getval_422()
{
    return 3523791497U;
}

void setval_329(unsigned *p)
{
    *p = 2430634824U;
}

unsigned getval_108()
{
    return 3264272009U;
}

void setval_355(unsigned *p)
{
    *p = 3286272329U;
}

unsigned addval_326(unsigned x)
{
    return x + 3229928137U;
}

unsigned getval_278()
{
    return 3375415689U;
}

unsigned addval_280(unsigned x)
{
    return x + 2425408137U;
}

void setval_304(unsigned *p)
{
    *p = 3286272328U;
}

void setval_319(unsigned *p)
{
    *p = 3281046185U;
}

unsigned addval_239(unsigned x)
{
    return x + 3531921032U;
}

void setval_482(unsigned *p)
{
    *p = 2428622473U;
}

unsigned getval_336()
{
    return 3229925773U;
}

void setval_370(unsigned *p)
{
    *p = 3525364425U;
}

unsigned addval_334(unsigned x)
{
    return x + 2428600696U;
}

unsigned getval_424()
{
    return 3286272330U;
}

unsigned getval_467()
{
    return 3374369433U;
}

unsigned getval_427()
{
    return 3599305827U;
}

unsigned getval_466()
{
    return 3252717896U;
}

void setval_423(unsigned *p)
{
    *p = 3676357001U;
}

unsigned addval_135(unsigned x)
{
    return x + 2425405825U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
